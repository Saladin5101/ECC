# ECC MVP\nELFCOST compiler supporting basic register operations.\n\nUsage:\n./elfc-compiler debug -el examples/test.elfc -ma output.bin
